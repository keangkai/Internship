
public class Car {
	
	private int plateID;
	private int price;
	
	public Car(int plateID, int price){
		setPlateID(plateID);
                setPrice(price);
	}
	
	public int getPlateID() {
		return plateID;
	}

	public void setPlateID(int plateID) {
		this.plateID = plateID;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	public String toString()
	{
		return "Plate ID: " + this.plateID + ", Price:" + this.price;
	}
	
	public static Car createCarFrom(Car car)
	{
		return new Car(car.plateID,car.price);
	}	
}
