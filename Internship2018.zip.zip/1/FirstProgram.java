package firstprogram;

/**
 *
 * @author Keangkai
 */
import java.util.*;
import java.util.Scanner;

public class FirstProgram {

    public static void main(String[] args) {
        int count = 0;
        Scanner sc = new Scanner(System.in);
        System.out.print("Count");
        String word1 = sc.next();
        String word2 = sc.next();

        if (word1.equals("vowel")) {
            System.out.println(Vowels(word2));
        } else if (word1.equals("alphabet")) {
            System.out.println(Alphabets(word2));
        } else if (word1.equals("digit")) {
            System.out.println(Digits(word2));
        } else if (word1.equals("lowercase")) {
            System.out.println(Lowercases(word2));
        } else if (word1.equals("uppercase")) {
            System.out.println(Uppercases(word2));
        } else {
            System.out.println("SomeThing is wrong");
        }

    }

    public static int Vowels(String word) {
        int count = 0;
        char[] wordc = word.toLowerCase().toCharArray();
        for (int i = 0; i < word.length(); i++) {
            if (wordc[i] == 'a' || wordc[i] == 'e' || wordc[i] == 'i' || wordc[i] == 'o' || wordc[i] == 'u') {
                count++;
            }
        }
        return count;
    }

    //Count alphabets
    public static int Alphabets(String str) {

        return str.length() - Vowels(str);
    }

    //Count digit
    public static int Digits(String str) {
        int count = 0;

        for (int i = 0; i < str.length(); i++) {
            if (Character.isDigit(str.charAt(i))) {
                count++;
            }
        }
        return count;
    }

    //Count lowercase
    public static int Lowercases(String str) {
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            if (Character.isLowerCase(str.charAt(i))) {
                count++;
            }
        }
        return count;
    }

    //Count uppercase
    public static int Uppercases(String str) {
        return str.length() - Lowercases(str);
    }
}
