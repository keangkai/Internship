package secondprogram;

/**
 *
 * @author Keangkai
 */
import java.util.*;
import java.util.Scanner;

public class SecondProgram {

    public static void main(String[] args) {
        Scanner Sc = new Scanner(System.in);

        System.out.print("formatter ");
        String Num1 = Sc.next();
        String Num2 = Sc.next();
        boolean isInteger = isInteger(Num1);
        char[] text = Num1.toCharArray();
        char[] chars = Num2.toCharArray();

        String output = "";
        int Format = Num2.length();
        int Text = Num1.length();
        int countPosText = 0;
        if (isInteger) {
            if (Text < Format) {
                for (int i = 0; i < Format; i++) {
                    if (countPosText < Text) {
                        if (chars[i] == '-') {
                            output += '-';
                            output += text[countPosText];
                            countPosText++;
                            i++;
                        } else {
                            output += text[countPosText];
                            countPosText++;
                        }
                    }
                }
            } else {
                System.out.println("Not correct");
            }
        } else {
            System.out.println("Not Integer");
        }
        System.out.println(output);
    }

    public static boolean isInteger(String str) {
        boolean isInteger = true;
        for (int i = 0; i < str.length(); i++) {
            if (Character.isDigit(str.charAt(i)) != true) {
                return false;
            }
        }
        return true;
    }
}
